ttyS[01234] is used for upstart <= 0.6.3, and it will be put in /etc/event.d/.
ttyS[01234].conf is used for upstart >= 0.6.3, and it will be put in /etc/init/.
